package com.example.myapplication;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.myapplication.Infraestructura.MyWebSocketClient;
import com.example.myapplication.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    private MyWebSocketClient socketClient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //socketClient.start();
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        String ip = "192.168.100.19";  // O usa la IP de tu dispositivo
        int port = 8008;
        String clientId = "getDeviceId()";
     /*   socketClient = new MyWebSocketClient(ip, port, clientId, new MyWebSocketClient.WebSocketMessageListener() {
            @Override
            public void onMessageReceived(final String message) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.d("Recibe",message);
                        //textView.setText(message);  // Mostrar el mensaje en la UI
                    }
                });
            }
            @Override
            public void onConnected() {
                Log.d("Cocetdao","✅ Conectado al servidor");

            }
            @Override
            public void onDisconnected() {
                Log.d("Desonectado","⚠️ Desconectado del servidor");

            }
            @Override
            public void onError(String error) {
                Log.d("Desonectado","⚠️ Desconectado del servidor"+error);
            }
        });
        Log.d("Desonectado","⚠️ Desconectado del servidor");
        socketClient.start();/*/

      /*  sendButton.setOnClickListener(v -> {
            String message = editText.getText().toString();
            MessageSocket messageSocket = new MessageSocket();
            messageSocket.setType("chat");
            messageSocket.setContent(message);

            // Enviar el mensaje al servidor
            socketClient.sendMessageToServer(messageSocket);
        });*/

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
     //   if (socketClient != null) {
           // socketClient.stop();
       // }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    public static String getDeviceId()
    {
        String serial = null;

        String m_szDevIDShort = "35" +
                Build.BOARD.length() % 10 + Build.BRAND.length() % 10 +
                Build.CPU_ABI.length() % 10 + Build.DEVICE.length() % 10 +
                Build.DISPLAY.length() % 10 + Build.HOST.length() % 10 +
                Build.ID.length() % 10 + Build.MANUFACTURER.length() % 10 +
                Build.MODEL.length() % 10 + Build.PRODUCT.length() % 10 +
                Build.TAGS.length() % 10 + Build.TYPE.length() % 10 +
                Build.USER.length() % 10; //13 bits

        try
        {

            //API>=9 use serial number
            Log.d("UID",new UUID(m_szDevIDShort.hashCode(), serial.hashCode()).toString());
            return new UUID(m_szDevIDShort.hashCode(), serial.hashCode()).toString();
        }
        catch (Exception exception)
        {
            //serial needs an initialization
            serial = "serial"; // Any initialization
        }

        //15-digit number pieced together using hardware information
        return new UUID(m_szDevIDShort.hashCode(), serial.hashCode()).toString();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}