package com.example.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;

import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.Infraestructura.MyWebSocketClient;
import com.example.myapplication.databinding.FragmentSecondBinding;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;
    private Handler reconnectHandler = new Handler();
    private int retryDelay = 5000;
    private MyWebSocketClient socketClient;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {binding = FragmentSecondBinding.inflate(inflater, container, false);return binding.getRoot();}

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


       // return binding.getRoot();
        String ip = "192.168.100.19";  // O usa la IP de tu dispositivo
        int port = 8008;
        String clientId = "getDeviceId()";
        socketClient = new MyWebSocketClient(ip, port, clientId, new MyWebSocketClient.WebSocketMessageListener() {
            @Override
            public void onMessageReceived(final String message) {
                Activity activity = getActivity();
                if (activity != null) {
                    activity.runOnUiThread(() -> {
                        Log.d("Recibe", message);
                        // Aquí puedes actualizar tu UI, por ejemplo con ViewBinding
                        // binding.textView.setText(message);
                    });
                }
            }
            @Override
            public void onConnected() {
                Log.d("Cocetdao","✅ Conectado al servidor");

            }
            @Override
            public void onDisconnected() {
                Log.d("Desonectado","⚠️ Desconectado del servidor");

            }
            @Override
            public void onError(String error) {
                Log.d("Desonectado","⚠️ Desconectado del servidor"+error);
            }
        });

       // socketClient.start();
        binding.buttonSecondy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
            }
        });
           /*  sendButton.setOnClickListener(v -> {
            String message = editText.getText().toString();
            MessageSocket messageSocket = new MessageSocket();
            messageSocket.setType("chat");
            messageSocket.setContent(message);

            // Enviar el mensaje al servidor
            socketClient.sendMessageToServer(messageSocket);
        });*/
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        if (socketClient != null) {
            socketClient.stop();
        }
    }

}